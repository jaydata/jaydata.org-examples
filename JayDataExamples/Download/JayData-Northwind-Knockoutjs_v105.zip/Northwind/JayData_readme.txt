﻿List of JayData files:

JayData.js					- JayData library (including customized jslint)
JayData.min.js				- minified JayData (including customized jslint)
JayData-vsdoc.js			- JayData library including customized jslint, used only in Visual Studio 2010 development time.
JaySvcUtil.exe				- OData metadata generator tool
CommandLine.dll				- required by metadata generator tool