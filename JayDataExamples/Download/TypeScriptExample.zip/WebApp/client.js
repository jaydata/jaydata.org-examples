var northwind = new WebApp.NorthwindEntities({
    name: "oData",
    oDataServiceHost: "http://localhost:60349/Northwind.svc"
});
$(function () {
    northwind.Categories.forEach(function (category) {
        return $('#categories').append($('<li>' + category.Category_Name + '</li>'));
    });
    northwind.Products.filter(function (product) {
        return product.Unit_Price < 50;
    }).orderBy(function (product) {
        return product.Category.Category_Name;
    }).toArray(function (products) {
        return products.forEach(function (product) {
            return $('#products').append('<li>' + product.English_Name + '</li>');
        });
    });
});
