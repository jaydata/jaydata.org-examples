///<reference path="Scripts/jQuery.d.ts" />
///<reference path="Scripts/Northwind.d.ts" />

var northwind = new WebApp.NorthwindEntities({ name: "oData", oDataServiceHost: "http://localhost:60349/Northwind.svc" });


$(() => {
    //list categories
    northwind
        .Categories
        .forEach(category => $('#categories').append($('<li>' + category.Category_Name + '</li>')));

    //list some products
    northwind
        .Products
        .filter( product => product.Unit_Price < 50 )
        .orderBy ( product => product.Category.Category_Name )
        .toArray(products => products
                                .forEach(product => $('#products')
                                .append('<li>' + product.English_Name + '</li>')));
});