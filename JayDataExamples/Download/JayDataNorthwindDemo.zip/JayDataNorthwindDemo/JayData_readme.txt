﻿List of JayData files:

JayData.js					- JayData library (including customized jslint)
JayData.min.js				- minified JayData (including customized jslint)
JaySvcUtil.exe				- OData metadata generator tool
CommandLine.dll				- required by metadata generator tool


index.html					- The HTML5 application that list products, categories,
							  and suppliers