class Product < ActiveRecord::Base
  attr_accessible :category_id, :discontinued, :product_name, :unit_price, :units_in_stock
end
