
class CategoriesController < ApplicationController
  def index
    @categories = Category.all

    respond_to do |format|
      format.xml { render xml: @categories, skip_types: true, dasherize: false }
    end
  end

  def show
    @category = Category.find(params[:id])

    respond_to do |format|
      format.xml { render xml: [ @category ], skip_types: true, dasherize: false }
    end
  end
end
