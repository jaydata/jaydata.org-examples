
class ProductsController < ApplicationController
  def index
    conditions = []
    unless (params[:category_id].blank?)
      conditions.push('category_id = ?', params[:category_id])
    end

    @products = Product.find(:all, conditions: conditions)

    respond_to do |format|
      format.xml { render xml: @products, skip_types: true, dasherize: false }
    end
  end

  def show
    @product = Product.find(params[:id])

    respond_to do |format|
      format.xml { render xml: [ @product ], skip_types: true, dasherize: false }
    end
  end
end
