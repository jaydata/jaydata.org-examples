class CreateProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.integer :category_id
      t.string :product_name
      t.float :unit_price
      t.integer :units_in_stock
      t.boolean :discontinued
    end
  end
end
